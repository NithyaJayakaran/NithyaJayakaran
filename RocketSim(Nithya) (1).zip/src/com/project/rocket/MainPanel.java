package com.project.rocket;

import java.awt.BorderLayout;

import javax.swing.JPanel;

public class MainPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5128429508235589854L;

	public MainPanel() {
		setLayout(new BorderLayout());
		add(new SkyBluePanel(),BorderLayout.NORTH);
		add(new GrassGreenPanel(),BorderLayout.SOUTH);
	}

}
