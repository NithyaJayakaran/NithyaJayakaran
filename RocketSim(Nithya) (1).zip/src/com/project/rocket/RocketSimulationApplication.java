package com.project.rocket;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class RocketSimulationApplication extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 158277209241738841L;

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			try {
				Frame frame = new Frame("Rocket Simulator");
				frame.setContentPane(new MainPanel());
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setLocationRelativeTo(null);
				frame.setResizable(false);
				frame.pack();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}

		});

	}
}
