package com.project.rocket;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class Frame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7311892219083543062L;
	public static int defaultWidth = 800;
	public static int defaultHeight = 600;
	public Dimension dimension;

	public Frame(String title, Boolean customTitleBar, int width, int height) {
		setTitle(title);

		dimension = new Dimension(width, height);

		setUndecorated(customTitleBar);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(dimension);
		setLocation(dim.width / 2 - getSize().width / 2, dim.height / 2 - getSize().height / 2);
	}

	public Frame(String title, int width, int height) {
		this(title, false, width, height);
	}

	public Frame(String title) {
		this(title, false, Frame.defaultWidth, Frame.defaultHeight);
	}
}
