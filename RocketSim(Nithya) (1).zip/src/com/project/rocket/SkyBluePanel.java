package com.project.rocket;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SkyBluePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4999131713030152431L;
	private BufferedImage rocket = null;
	private int initialY = 450;
	private int initialX = 320;
	private JPanel labelPanel;
	private JLabel massLabel;
	private JTextField massLabelValue;
	private JLabel thrustForceLabel;
	private JTextField thrustForceValue;
	private BufferedImage rotated;

	public SkyBluePanel() {
		// TODO Auto-generated constructor stub
		setPreferredSize(new Dimension(800, 500));
		setName("SkyBluePanel");
		setBackground(Color.BLUE);

		labelPanel = new JPanel();
		labelPanel.setName("Label Panel");
		labelPanel.setLayout(new GridLayout(0, 2, 1, 1));
		labelPanel.setBackground(Color.BLUE);

		massLabel = new JLabel("Mass (kg)");
		massLabel.setName("massLabel");
		massLabelValue = new JTextField("0.0");
		massLabelValue.setName("massValue");

		thrustForceLabel = new JLabel("Thrust Force (Newtons)");
		thrustForceLabel.setName("thrustForceLabel");
		thrustForceValue = new JTextField("0.0");
		thrustForceValue.setName("thrustValue");

		labelPanel.add(massLabel);
		labelPanel.add(massLabelValue);
		labelPanel.add(thrustForceLabel);
		labelPanel.add(thrustForceValue);

		try {
			rocket = ImageIO.read(this.getClass().getResource("/images/rocket26.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		add(labelPanel, BorderLayout.AFTER_LAST_LINE);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		rotated = rotateImageByDegrees(rocket, initialX, initialY);
		Graphics2D g2d = (Graphics2D) g.create();
		if (initialX == 320 && initialY == 450) {
			g2d.drawImage(rocket, initialX, initialY, this);

		} else {

			g2d.drawImage(rotated, initialX, initialY, this);
			g2d.dispose();
		}
	}

	public int getInitialY() {
		return initialY;
	}

	public void setInitialY(int initialY) {
		this.initialY = initialY;
	}

	public int getInitialX() {
		return initialX;
	}

	public void setInitialX(int initialX) {
		this.initialX = initialX;
	}

	public BufferedImage rotateImageByDegrees(BufferedImage img, double x, double y) //this is where the frame reiterates again and again
	{

		double rads = Math.atan2(-x, y); //we increment dx and dy, but to do vector addition I am going to do arctan
		double sin = Math.abs(Math.sin(rads)), cos = (Math.cos(rads)); //Math.abs
		int w = img.getWidth();
		int h = img.getHeight();
		int newWidth = (int) Math.floor(w * cos + h * sin);
		int newHeight = (int) Math.floor(h * cos + w * sin);

		BufferedImage rotated = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = rotated.createGraphics();
		AffineTransform at = new AffineTransform(); //this constructor is using affine tranform which allows me to rotate the rocket without messing its trajectory
		at.translate((newWidth - w) / 2, (newHeight - h) / 2);

		int p = w / 2;
		int q = h / 2;

		at.rotate(rads, p, q);
		g2d.setTransform(at);
		g2d.drawImage(img, 0, 0, this);
		g2d.dispose();

		return rotated;
		
	}
}


	
		/*if (acceleration == 0) {
			DialogInput = JOptionPane.showConfirmDialog(null, "Please provide mass and thrust force values ",
				"Provide Values", JOptionPane.WARNING_MESSAGE);
		} 
		
			else 
				{
					DialogInput = 1;
				}

	*/
	/*
	 public BufferedImage (BufferedImage img, double ) {
	 	int xpos = img.getWidth();
		int ypos = img.getHeight();
		int newXpos = (int) Math.floor(xpos + (TANGENTIAL_VELOCITY * HALF_SECOND));
		int newYpos = (int) Math.floor(ypos + (acceleration * 0.5 * HALF_SECOND * HALF_SECOND));
		
	 	return newXpos;
	 	return newYpos;
	 }
	 */
