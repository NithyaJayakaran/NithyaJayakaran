package com.project.rocket;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

public class GrassGreenPanel extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5734530792184701117L;
	private final static int HALF_SECOND = 500; //NOT EXACTLY HALF A SECOND BUT WHEN THE ITERATION HAPPENS AGAIN
	private final static double TANGENTIAL_VELOCITY = 1667.92; //CALCULATED IN GOOGLE DOCS
	private final static int THOUSAND = 1000;

	private JPanel buttonPanel;
	private JPanel labelPanel;
	private JButton launchButton;
	private JButton resetButton;
	private GridBagConstraints gbc;
	private Timer timer;
	private SkyBluePanel bluePanel = null;
	private JLabel speedLable;
	private JLabel currentHeight;
	private JLabel timeElapsed;
	private JTextField speedValue;
	private JTextField heightValue;
	private JTextField timeElapsedValue;
	private double thrustForce = 0.0;
	private double mass = 0.0;
	private int confirmationDialogInput = 1;

	public GrassGreenPanel() {

		setPreferredSize(new Dimension(800, 100));
		setBackground(Color.GREEN);
		setLayout(new BorderLayout());

		buttonPanel = new JPanel();
		buttonPanel.setPreferredSize(new Dimension(200, 100));
		buttonPanel.setLayout(new GridBagLayout());
		buttonPanel.setBackground(Color.GREEN);

		launchButton = new JButton("Launch");
		resetButton = new JButton("Reset");
		launchButton.setPreferredSize(new Dimension(100, 30));
		resetButton.setPreferredSize(new Dimension(100, 30));

		launchButton.addActionListener(this);
		resetButton.addActionListener(this);

		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(3, 3, 3, 3);
		buttonPanel.add(launchButton, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		buttonPanel.add(resetButton, gbc);

		labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(0, 2, 1, 1));
		labelPanel.setBackground(Color.GREEN);

		speedLable = new JLabel("Current Speed");
		speedValue = new JTextField(" 0 Kmph");
		speedValue.setBackground(Color.GREEN);
		speedValue.setSize(200, 30);
		speedValue.setBorder(null);

		currentHeight = new JLabel("Current Height");
		heightValue = new JTextField(" 0 KM");
		heightValue.setBackground(Color.GREEN);
		heightValue.setBorder(null);

		timeElapsed = new JLabel("Time Elapsed ");
		timeElapsedValue = new JTextField(" 0 seconds");
		timeElapsedValue.setBackground(Color.GREEN);
		timeElapsedValue.setBorder(null);

		labelPanel.add(speedLable);
		labelPanel.add(speedValue);
		labelPanel.add(currentHeight);
		labelPanel.add(heightValue);
		labelPanel.add(timeElapsed);
		labelPanel.add(timeElapsedValue);

		launchButton.setPreferredSize(new Dimension(100, 30));
		resetButton.setPreferredSize(new Dimension(100, 30));

		add(buttonPanel, BorderLayout.EAST);
		add(labelPanel, BorderLayout.WEST);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (confirmationDialogInput != 0) {
			if (e.getActionCommand() == "Launch") {
				getBluePanelComponents();

				launchButton.setEnabled(false);

				timer = new Timer(HALF_SECOND, new ActionListener() {
					double time = 0.5;

					public void actionPerformed(ActionEvent evt) {
						getPosition(time);
						time = time + 0.5;
						// System.out.println("x " + newPosition.getX() + " y:" + newPosition.getY());

					}
				});
				timer.start();
				// bluePanel.repaint();
			} else {
				timer.stop();
				launchButton.setEnabled(true);
				bluePanel.setInitialY(450);
				bluePanel.setInitialX(320);
				bluePanel.repaint();
			}
		}

	}

	private void getPosition(double time) {
		// TODO Auto-generated method stub

		double acceleration = 0.0;
		double accelerationInKiloMeter = 0.0;
		double heightInKiloMeter = 0.0;

		acceleration = (thrustForce - (mass * 9.8)) / mass; //ACCELREATION CALCULATED
		System.out.println("Acceleration " + acceleration);
		accelerationInKiloMeter = acceleration * 12960; // converting to KMPH
		speedValue.setText(String.valueOf(Math.round(accelerationInKiloMeter)) + " KMPH");
		System.out.println("accerlation in KMPH " + accelerationInKiloMeter);
		speedValue.repaint();

		double deltaYPosition = 0.5 * acceleration * time * time;
		bluePanel.setInitialY(bluePanel.getInitialY() - (int) Math.round(deltaYPosition));
		heightInKiloMeter = (Math.round(deltaYPosition * 100.0) / 100.0); // conversion to KM
		heightValue.setText(heightInKiloMeter + " KM");
		heightValue.repaint(); //THE PANEL IS REDRAWN AS IT INCREMMENTS IN VERTICAL DIRECTION

		timeElapsedValue.setText(time + " seconds"); //THIS IS ELAPSED TIME COUNTER
		timeElapsedValue.repaint();

		double deltaXPosition = (TANGENTIAL_VELOCITY * time) / THOUSAND; // Divided by 1000 because x position was going
																			// beyond the JPanel width
		bluePanel.setInitialX(bluePanel.getInitialX() + (int) Math.round(deltaXPosition));
		bluePanel.repaint();

	}

	private void getBluePanelComponents() {
		Container parentPanel = this.getParent(); //ATTRIBUTES ONLY FOR THIS PARENTS METHOD INHERETANCE
		Component comps[] = parentPanel.getComponents();
		if (bluePanel == null) {
			for (int i = 0; i < comps.length; i++) {
				if (comps[i].getName().equals("SkyBluePanel")) {
					bluePanel = (SkyBluePanel) comps[i];
					break;
				}
			}
		}

		Component bluePanelComps[] = bluePanel.getComponents();
		JPanel labelPanelComp = (JPanel) bluePanelComps[0];
		Component textFieldComps[] = labelPanelComp.getComponents();
		for (int i = 0; i < textFieldComps.length; i++) {
			if (textFieldComps[i].getName().equals("massValue")) {
				JTextField massValue = (JTextField) textFieldComps[i];
				mass = Double.valueOf(massValue.getText());

			}
			if (textFieldComps[i].getName().equals("thrustValue")) {
				JTextField thrustValue = (JTextField) textFieldComps[i];
				thrustForce = Double.valueOf(thrustValue.getText());
			}

		}
		
		//DIALOGUE BOX WHEN THERE IS NO INPUTED VALUE ERROR MESSAGE

		if (mass == 0.0 || thrustForce == 0.0) {
			confirmationDialogInput = JOptionPane.showConfirmDialog(null, "Please provide mass and thrust force values ",
					"Provide Values", JOptionPane.WARNING_MESSAGE);

		} else {
			confirmationDialogInput = 1;
		}

	}

}
